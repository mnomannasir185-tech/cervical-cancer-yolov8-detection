from ultralytics import YOLO

def main():
    # Start with nano for sanity, then move to x for final experiments
    model = YOLO("yolov8n.pt")

    model.train(
        data="configs/data.yaml",
        epochs=100,
        imgsz=640,
        batch=16,
        lr0=0.001,
        optimizer="AdamW",
        weight_decay=0.0005,
        patience=30,
        augment=True,
        degrees=5,
        fliplr=0.5,
        mosaic=0.3,
        mixup=0.1,
        close_mosaic=10,
        project="runs",
        name="cervical_detection"
    )

if __name__ == "__main__":
    main()
