from ultralytics import YOLO

def main():
    model = YOLO("runs/cervical_detection/weights/best.pt")

    results = model.predict(
        source="data/val/images",
        imgsz=640,
        conf=0.25,
        save=True,
        project="runs",
        name="predictions"
    )

    print("Inference completed.")

if __name__ == "__main__":
    main()
