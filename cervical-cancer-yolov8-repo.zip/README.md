# Cervical Cancer Early Detection using YOLOv8

This repository presents a deep learning pipeline for **early cervical cancer detection** using **YOLOv8 object detection** on cervix image datasets.

The objective is to identify and localize **abnormal cervical cells** for improved screening accuracy and earlier diagnosis.

## Why this matters

Early detection of cervical cancer significantly improves treatment outcomes. Manual screening is time-consuming and subject to variability. This project applies AI-based object detection for reliable and scalable clinical decision support.

## Model

- YOLOv8 for abnormal cell detection
- CLAHE preprocessing for contrast enhancement
- Data augmentation for robustness
- Optimized training using AdamW + augmentation strategies

## Dataset Structure

```text
data/
├── train/
│   ├── images/
│   └── labels/
├── val/
│   ├── images/
│   └── labels/
```

YOLO label format is required.

## Install

```bash
pip install -r requirements.txt
```

## Train

```bash
python scripts/train.py
```

## Predict

```bash
python scripts/predict.py
```

## Future Improvements

- Compare YOLOv8n vs YOLOv8x
- Add mAP, Precision, Recall reporting
- Add Grad-CAM explainability
- Clinical benchmarking for publication

## Author

M Noman Nasir  
MPhil Medical Physics | AI Researcher | Medical Imaging + Deep Learning
